import React from 'react';
import Navigation from '../components/Navigation';


const Home = () => {
    return (
        <div>
            <Navigation />
            <h1>Accueil</h1>
            <h2>Test affichage</h2>
        </div>
    );
};

export default Home;