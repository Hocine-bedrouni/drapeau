import React from 'react';
import Navigation from '../components/Navigation';


const About = () => {
    return (
        <div>
            <Navigation/>
            <h1>A propos</h1>
            <br/>
            <p> Petit speech pour tester des choses bla bala
            Petit speech pour tester des choses bla bala
            Petit speech pour tester des choses bla bala
            </p>
        </div>
    );
};

export default About;