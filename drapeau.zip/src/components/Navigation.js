import {NavLink} from 'react-router-dom'
import React from 'react';

const navigation = () => {
    return (
        <div className='Navbar'>
            <ul>
                <NavLink to="/home">
                    <li>accueil</li>
                </NavLink>
                <NavLink to="/about">
                    <li>à propos</li>
                </NavLink>
            </ul>
            
        </div>
    );
};

export default navigation;